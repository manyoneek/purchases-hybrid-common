# Current price-contract reproduction

Baseline: Hybrid Common `ed23f3f08d1abe97d0ebe591b708bb984f8c2ced` (19.15.1). Native RevenueCat 5.98.0; purchases-js 1.73.1. Tested with Xcode 27.1 RC / iOS 27.1 simulator, Node 22, CocoaPods 1.17.0. The native reproduction target uses iOS 27 for this capture; SDK support minimums are unchanged.

Dedicated project: SDK Bug Reporter (`proj602cc762`), Test Store app `app4ca00b430f`.
Dashboard: https://app.revenuecat.com/projects/602cc762/apps/app4ca00b430f

Set your dedicated Test Store public SDK key in `native-app/Config.swift` and `web-app/config.js`. Keys are deliberately omitted. Recreate `bug_reporter_monthly` ($9.99/month) and `bug_reporter_lifetime` ($19.99 non-consumable); put the monthly product first in the current offering. Each run generates a synthetic user. Neither client purchases anything.

## Native before and after

1. In `native-app`, run `xcodegen generate` then `pod install`.
2. Open `SharedPriceRepro.xcworkspace`, choose an iOS simulator, and run. The app automatically calls the real `CommonFunctionality.getProductInfo` and evaluates a null-guarded JavaScript consumer. Baseline: 4 pass / 7 fail.
3. Run `git -C sdk apply ../ios-fix.patch` from this directory. Rebuild and run the SAME app. Expected: 11 pass / 0 fail.
4. Use `git -C sdk apply -R ../ios-fix.patch` to undo. The included snapshot needs no git history for `git apply`.

Native XCTest regression: in `sdk/ios/PurchasesHybridCommon`, `pod install`, then `xcodebuild test -workspace PurchasesHybridCommon.xcworkspace -scheme PurchasesHybridCommon -destination 'platform=iOS Simulator,name=YOUR_SIMULATOR' CODE_SIGNING_ALLOWED=NO`. For fail-before testing, apply the patch's test-file changes only while leaving the production mapper unchanged. Exact observed commands and results are in the evidence logs.

## Web-only before and after

1. Serve `web-app` with `python3 -m http.server 8898 --bind 127.0.0.1 --directory web-app`.
2. Open `http://127.0.0.1:8898/?variant=before` and click Run. Baseline: 1 pass / 3 fail.
3. Open the same client with `?variant=fixed`. Expected: 4 pass / 0 fail. The shipped bundles are source-built from the baseline and web-only fix respectively.
4. To rebuild: in `sdk/purchases-js-hybrid-mappings`, `corepack yarn install --frozen-lockfile` and `npm run build`; copy `dist/index.umd.js` to `web-app/before.js`. Apply `web-fix.patch` from the source root using `git -C sdk apply ../web-fix.patch`, rebuild, and copy to `web-app/fixed.js`.

Web unit suite: `npm test -- --runInBand`. API validation: `npm run api-test:ci`. The production public methods are used by the browser; only unit tests use fixtures. If your app divides these values by 1,000,000 as a workaround, remove that workaround when adopting this fix.

The native and web patches fix separate defects. Apply only the relevant patch when verifying one finding.
