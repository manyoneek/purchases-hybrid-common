# Review coverage — 2026-10-17

## Inventory and rotation

Refreshed all 77 public RevenueCat GitHub repositories through the public org repository API, including 21 forks and 3 archives. Verified all 77 local clone origins. No missing clones, new clones, or failures. Saved full API inventory, clone checks, initial checkout status and fetch logs. Original clones are unchanged.

Reviewed RevenueCat/purchases-hybrid-common at `d1744f694c5cdd3a27baa527c6e1e46d33f4b796` (19.13.0) in an isolated detached worktree. Its pinned dependencies are RevenueCat iOS 5.95.0 and purchases-js 1.70.0. purchases-capacitor was also fetched into a detached candidate worktree, but no implementation review or test coverage is claimed for it in this run. Next rotation target: purchases-ios.

## Source coverage

Inspected iOS CommonFunctionality purchase parameter validation/dispatch, product and offering fetch callbacks, attribute nil forwarding, cache access, subscription/transaction serializers, product and discount serializers, PaywallCustomVariables NSNumber/boolean distinction; shared TypeScript product contracts; web offering/product/subscription-option, customer-info and purchase-result mapping; adjacent Android StoreProductMapper null and unit conversion behavior. Dynamic regressions focused on product period-price fields. Android was source-only.

Two independent fingerprints, both new to the ledger:

- `hybrid-common:ios-product-period-prices:nil-subscript-removes-null-fields`.
- `hybrid-common:web-period-prices:amountMicros-not-converted`.

Bounded public issue/PR searches covered pricePerWeek, null price, micros, period price, plus the latest 100 PR titles. PR #1195 establishes nullable public types; it changed declarations only and does not fix missing iOS keys. PR #621 introduced per-period fields. No matching implementation fix was identified. Other known installment mapping issue #1793 is not reported here. No GitHub writes.

## Baselines and regressions

- iOS existing XCTest suite: 161 passing tests.
- Web mappings: 57 passing tests.
- Shared TypeScript: 30 passing tests; build passes. Existing apitests command fails with TS5058 because `apitesters/` is absent. No full API compatibility pass claimed.
- Added 7 iOS cases in the real StoreProduct serializer suite: six null cases fail before, each with dictionary and JSON assertions; subscription control passes. Selected suite totals 24 cases: 18 pass, 6 fail / 12 failed assertions. Restored-source rerun exits 65 with the same failures.
- Native full fixed suite: all 168 pass. Old dictionary count assertion changes from 12 to 18 to include six explicit null entries.
- Added 5 web cases against the actual mapper: 3 conversion failures, 2 passing null/zero controls; temporary fix passes all 5. Full fixed suite passes all 62 after correcting existing expectations that codified micros output.
- Strict TypeScript consumer compiles against actual public types; the same null-guard expression throws when JavaScriptCore receives the real unfixed native dictionary.

## Actual app flows

Native SharedPriceRepro directly links the actual public shared iOS library, configures a synthetic user, fetches real monthly/lifetime products with CommonFunctionality.getProductInfo, serializes the result and runs a JavaScriptCore consumer. 4 pass / 7 fail before; 11 pass / 0 fail after. This is a native shared-library client, not a wrapper-framework end-to-end claim. iOS 27.1 simulator only; no physical-device or Android test.

The web-only client calls actual PurchasesCommon.configure/getCustomerInfo/getOfferings using the built production bundle and live Test Store data. 1 pass / 3 fail before; 4 pass / 0 fail after. No native mobile reproduction of the web bug is claimed. Neither flow mocks transport or injects callbacks. Neither defect requires a purchase, and none was attempted.

Before/after videos preserve actual simulator/browser execution; all delivery screenshots and final frames from all four videos were visually checked. Browser recording used the managed openclaw profile over its existing CDP connection. The initial native screenshot was too tall to show the consumer; retained as draft evidence, then compacted the UI and recaptured the same original implementation. Delivery uses the compact complete capture.

## Authorized Test Store setup

Project SDK Bug Reporter `proj602cc762`, app Test Store `app4ca00b430f`. Reused monthly product and offering. Created only `bug_reporter_lifetime` / `prod49bcf1486e` (non-consumable) and USD 19.99 price with official `rc products create` / `rc products prices set`. Saved exact responses and official `rc open apps ... --print` dashboard URL. All users are synthetic. No unrelated projects or real customer accounts touched.

## Restoration and evidence

Both minimal production fixes were applied in try/finally scopes, verified with same-app runs and full suites, then restored byte-for-byte. Only regression test additions remain in the isolated review worktree. Original clones match their initial statuses. Patches, SHA pins, source hashes, tests, logs, source clients and media are retained. A clean git archive of the exact commit supplies the source package; its native app build is independently checked before packaging.

## Tooling failures and recovery

`rg` was unavailable; used grep/Python. Concurrent Yarn installs encountered a shared-cache missing metadata error; an isolated cache retry succeeded. CocoaPods was outside PATH; used existing Ruby 4.0/CocoaPods 1.17 installation. Reproduction harness first had an unterminated Swift string, then attempted an SPI-only property; corrected the string and used the public hybrid configure method. These were harness failures, not reported SDK bugs.

The first expected-failing XCTest run completed assertions but stalled collecting failure diagnostics. Stopped only that xcodebuild process and reran with `-collect-test-diagnostics never`; got normal exit 65 and matching failures. Fixed full run exits 0. Independently staged CocoaPods initially rejected ASCII locale; set UTF-8 locally in the delivered build script and retried. No host shell/config or schedule changes.

Reports and evidence are delivered only through the scheduled final for Discord channel 1559550752349884437. No duplicate message calls; delivery receipt is unavailable within this run. No issues, PRs, comments, pushes, support requests or new schedules.

Independent packaged build also encountered full host storage. Freed only this run's regenerable derived build intermediates/module caches, incomplete packaged derived output and isolated Yarn cache (~1.2 GiB). Source, tests, patches, logs, media, xcresult bundles and prior artifacts were preserved. Retried the clean-source package build. No unrelated files or other projects were cleaned.
