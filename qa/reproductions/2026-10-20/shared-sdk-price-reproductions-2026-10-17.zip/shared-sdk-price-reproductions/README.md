# Shared SDK price regressions — 2026-10-17

Repository: RevenueCat/purchases-hybrid-common, commit `d1744f694c5cdd3a27baa527c6e1e46d33f4b796` (19.13.0).
Native dependency: RevenueCat iOS 5.95.0. Web dependency: purchases-js 1.70.0.
The `worktrees/purchases-hybrid-common` directory is the exact original source from git archive; no diagnostic fix is applied.

## Native iOS shared-library client

Requires Xcode, an iOS simulator, CocoaPods and XcodeGen. Tested with iOS 27.1 simulator / Xcode 27.0.
Ensure `pod` and its matching Ruby are on PATH. Use `xcrun simctl list devices available` and boot your selected simulator.

```sh
export QA_SIMULATOR=<booted-simulator-UDID>
./build-native.sh before
./build-native.sh fixed
```

Each launch fetches the real dedicated monthly and lifetime products through `CommonFunctionality.getProductInfo`, displays all assertions, and writes `Documents/results.json` in the app data container. Original: 4 pass / 7 fail. Fixed: 11 pass / 0 fail. The fixed build restores source on exit.

The JavaScriptCore consumer uses the actual returned product dictionary. It demonstrates a strict-null-guard failure accepted by the shared TypeScript type; it is not a Cordova/React Native wrapper reproduction. The iOS app itself exercises the public shared library and real Test Store product fetch. No purchase is needed.

Optional video/results runner (requires ffmpeg only for later video inspection, not capture): `QA_DISPLAY=1 python3 run-native-regression.py replay`. Set QA_DISPLAY to the simulator's correct display number; iPhone Duo used 1. It exits 1 for the expected original failures and 0 for fixed results.

## Web-only shared-library client

A runnable prebuilt bundle for each variant is included. Start:

```sh
python3 -m http.server 8887 --bind 127.0.0.1 --directory web-app
```

Open `http://127.0.0.1:8887/?variant=before`, click **Run actual SDK flow**, then repeat with `?variant=fixed`. Original: 1 pass / 3 fail. Fixed: 4 pass / 0 fail. It calls the real `PurchasesCommon.configure`, `getCustomerInfo` and `getOfferings` APIs. Numeric per-period prices are compared with the real USD formatted prices, with a one-cent rounding tolerance. No mocked network or injected callback fixture.

Rebuild both bundles from included source with `./build-web.sh` (Node/Corepack required). This script restores source after building the fixed variant.

## Focused and broader regression tests

From `worktrees/purchases-hybrid-common`, apply `patch -p1 < ../../web-regression.patch` and `patch -p1 < ../../ios-regression.patch`. These add only the focused regressions. Run before production patches, then apply `web-suggested-fix.patch` / `ios-suggested-fix.patch` and repeat. Before running the full fixed suites, also apply the corresponding `web-existing-expectations.patch` / `ios-existing-expectations.patch`, which correct old assertions that codified the defects.

Web: `cd purchases-js-hybrid-mappings && corepack yarn install --frozen-lockfile && npm test -- --runInBand --testNamePattern='QA public currency-unit contract'`. Before: 3 fail / 2 pass; fixed: 5 pass. Full fixed `npm test -- --runInBand`: 62 pass.

Native: `cd ios/PurchasesHybridCommon && pod install`, then:

```sh
xcodebuild test -workspace PurchasesHybridCommon.xcworkspace -scheme PurchasesHybridCommon \
  -destination "platform=iOS Simulator,id=$QA_SIMULATOR" \
  -only-testing:PurchasesHybridCommonTests/StoreProductHybridAdditionsTests \
  -collect-test-diagnostics never CODE_SIGNING_ALLOWED=NO IPHONEOS_DEPLOYMENT_TARGET=15.0
```

Six added null-field cases fail before (two assertions each); the subscription control passes. Full fixed suite without `-only-testing`: 168 pass. Baseline before adding regressions: 161 pass. Existing null-product dictionary-size expectation changes from 12 to 18 only for the corrected contract. The separate existing-expectations patch makes this correction only when testing the fix.

TypeScript: `typescript` has 30 passing tests and builds successfully. Its existing `apitests` command fails because `apitesters/` is missing; no full API-suite pass is claimed. `qa-null-guard.ts` compiles from the artifact root with `worktrees/purchases-hybrid-common/typescript/node_modules/.bin/tsc --strict --noEmit --skipLibCheck --target es2020 --moduleResolution node qa-null-guard.ts` after installing the TypeScript package dependencies.

## Dedicated backend setup

Project **SDK Bug Reporter** (`proj602cc762`), app **Test Store** (`app4ca00b430f`): https://app.revenuecat.com/projects/602cc762/apps/app4ca00b430f

Only synthetic users are created. Existing monthly product is `bug_reporter_monthly` ($9.99/month); this run created `bug_reporter_lifetime` ($19.99, non-consumable). Public Test Store SDK key is in native-app/Config.swift and web-app/config.js. No secret/admin credentials are included. No store purchase, checkout, or real charge is performed. No Android or physical-device reproduction is claimed.

Reports, before/after screenshots and videos, results, patches and logs are included. Evidence is from the actual clients; no replacement payloads or transport fixtures are used in app flows. Unit tests separately use product fixtures.
