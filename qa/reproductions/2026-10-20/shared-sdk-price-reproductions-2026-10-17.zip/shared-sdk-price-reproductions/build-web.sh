#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
root="$PWD"
cd worktrees/purchases-hybrid-common/purchases-js-hybrid-mappings
corepack yarn install --frozen-lockfile
npm run build
cp dist/index.umd.js "$root/web-app/before.js"
cd ..
patch -p1 < "$root/web-suggested-fix.patch"
trap 'patch -R -p1 < "$root/web-suggested-fix.patch"' EXIT
(cd purchases-js-hybrid-mappings && npm run build)
cp purchases-js-hybrid-mappings/dist/index.umd.js "$root/web-app/fixed.js"
