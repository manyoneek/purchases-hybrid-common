import type { PurchasesStoreProduct } from './worktrees/purchases-hybrid-common/typescript/src/offerings';
export function monthlyLabel(product: PurchasesStoreProduct): string {
  return product.pricePerMonth !== null ? product.pricePerMonth.toFixed(2) : 'not applicable';
}
