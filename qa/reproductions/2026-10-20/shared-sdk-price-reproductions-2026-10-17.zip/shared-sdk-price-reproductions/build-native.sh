#!/usr/bin/env bash
set -euo pipefail
export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8
cd "$(dirname "$0")"
variant="${1:-before}"
simulator="${QA_SIMULATOR:?Set QA_SIMULATOR to a booted iOS simulator UDID}"
source_dir="$PWD/worktrees/purchases-hybrid-common"
restore_fix() { if [ "$variant" = fixed ]; then (cd "$source_dir" && patch -R -p1 < ../../ios-suggested-fix.patch); fi; }
if [ "$variant" = fixed ]; then
  (cd "$source_dir" && patch -p1 < ../../ios-suggested-fix.patch)
  trap restore_fix EXIT
elif [ "$variant" != before ]; then echo "Usage: $0 before|fixed" >&2; exit 2; fi
cd native-app
xcodegen generate
pod install
xcodebuild build -workspace SharedPriceRepro.xcworkspace -scheme SharedPriceRepro -destination "platform=iOS Simulator,id=$simulator" -derivedDataPath ../derived CODE_SIGNING_ALLOWED=NO
cd ..
xcrun simctl terminate "$simulator" com.revenuecat.sdkbugreporter.sharedprice 2>/dev/null || true
xcrun simctl install "$simulator" derived/Build/Products/Debug-iphonesimulator/SharedPriceRepro.app
xcrun simctl launch "$simulator" com.revenuecat.sdkbugreporter.sharedprice
