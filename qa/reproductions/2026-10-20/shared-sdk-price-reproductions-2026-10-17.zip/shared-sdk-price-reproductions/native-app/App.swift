import SwiftUI
import JavaScriptCore
import PurchasesHybridCommon
@_spi(Internal) import RevenueCat

@main struct SharedPriceReproApp: App {
    var body: some Scene { WindowGroup { ReproView() } }
}
struct ReproView: View {
    @State private var text = "Ready to fetch real Test Store products."
    @State private var running = false
    @State private var failed = 0
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("SDK Bug Reporter").font(.title.bold())
                Text("Shared iOS product serialization").font(.title2)
                Text("PHC 19.13.0 · d1744f694c5c\nRevenueCat iOS 5.95.0 · Test Store").font(.caption)
                Text("Expected: lifetime product's six period-price fields are explicit nulls. Monthly control keeps numeric prices.")
                Button(running ? "Fetching…" : "Run actual SDK flow") { run() }.buttonStyle(.borderedProminent).disabled(running)
                Text(text).font(.system(size: 12, design: .monospaced)).textSelection(.enabled)
                Text("Shared-library client on native iOS. Real product fetch; no callback injection or mocked transport.").font(.caption).foregroundStyle(.secondary)
            }.padding(24)
        }.onAppear { if !running { DispatchQueue.main.asyncAfter(deadline: .now()+1) { run() } } }
    }
    func run() {
        running = true
        let user = "bug-reporter-price-" + UUID().uuidString
        text = "Configuring synthetic user…\nFetching lifetime + monthly products…"
        if !Purchases.isConfigured {
            _ = Purchases.configure(apiKey: testStoreKey, appUserID: user, purchasesAreCompletedBy: nil, userDefaultsSuiteName: nil, platformFlavor: "qa-shared-client", platformFlavorVersion: "1.0", dangerousSettings: nil, verificationMode: nil, useExternalPurchaseCustomLinks: false, enableExternalPurchasesInSimulator: false)
        }
        CommonFunctionality.getProductInfo(["bug_reporter_lifetime", "bug_reporter_monthly"]) { products in
            DispatchQueue.main.async {
                do {
                    let keys = ["pricePerWeek", "pricePerMonth", "pricePerYear", "pricePerWeekString", "pricePerMonthString", "pricePerYearString"]
                    var checks: [[String: Any]] = []
                    var lines: [String] = []
                    func check(_ name: String, _ pass: Bool, _ actual: Any) {
                        checks.append(["name": name, "pass": pass, "actual": actual])
                        lines.append("\(pass ? "PASS" : "FAIL") \(name): \(actual)")
                    }
                    check("two real products", products.count == 2, products.count)
                    guard let lifetime = products.first(where: { ($0["identifier"] as? String) == "bug_reporter_lifetime" }),
                          let monthly = products.first(where: { ($0["identifier"] as? String) == "bug_reporter_monthly" }) else { throw NSError(domain: "Missing products", code: 1) }
                    for key in keys { check("lifetime." + key, lifetime[key] is NSNull, lifetime[key] ?? "<missing>") }
                    for key in keys.prefix(3) { check("monthly." + key, monthly[key] is NSNumber, monthly[key] ?? "<missing>") }
                    let payload = try JSONSerialization.data(withJSONObject: lifetime, options: [.sortedKeys])
                    let js = JSContext()!
                    let script = "(() => { const product = " + String(decoding: payload, as: UTF8.self) + "; try { return product.pricePerMonth !== null ? product.pricePerMonth.toFixed(2) : 'not applicable'; } catch(e) { return e.name + ': ' + e.message; } })()"
                    let consumer = js.evaluateScript(script)!.toString()!
                    check("documented null guard", consumer == "not applicable", consumer)
                    let count = checks.filter { !($0["pass"] as! Bool) }.count
                    let result: [String: Any] = ["finished": true, "checks": checks, "failed": count, "passed": checks.count-count, "products": products, "syntheticUser": Purchases.shared.appUserID, "projectId": "proj602cc762", "appId": "app4ca00b430f"]
                    let output = try JSONSerialization.data(withJSONObject: result, options: [.prettyPrinted, .sortedKeys])
                    let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("results.json")
                    try output.write(to: url)
                    running = false; failed = count; text = "\(checks.count-count) passed / \(count) failed\n\n" + lines.joined(separator: "\n")
                } catch {
                    text = "Flow failed: \(error)"
                    let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("results.json")
                    try? JSONSerialization.data(withJSONObject: ["error": String(describing: error)]).write(to: url)
                }
            }
        }
    }
}
