# Reproduction source and original evidence

Original capture date: 2026-10-17. Original reviewed commit: d1744f694c5cdd3a27baa527c6e1e46d33f4b796. The recorded app/client was run before and after the suggested fix on that revision. Fresh branch-level tests are published separately; these captures were not rerun on the latest upstream revision.

Replace test_REPLACE_WITH_YOUR_PUBLIC_TEST_STORE_KEY in the client configuration with your public RevenueCat Test Store SDK key before running.
