window.testStoreKey = "test_REPLACE_WITH_YOUR_PUBLIC_TEST_STORE_KEY";
