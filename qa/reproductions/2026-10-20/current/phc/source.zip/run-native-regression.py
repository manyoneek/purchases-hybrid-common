#!/usr/bin/env python3
import subprocess,pathlib,time,json,signal,sys,os
root=pathlib.Path(__file__).resolve().parent
label=sys.argv[1] if len(sys.argv)>1 else 'before'
(root/'evidence').mkdir(exist_ok=True)
display=os.environ.get('QA_DISPLAY','1')
udid=os.environ.get('QA_SIMULATOR','286DC73D-2455-4F1B-A4A2-56E3BDEE64D9'); bundle='com.revenuecat.sdkbugreporter.sharedprice'
app=root/'derived/Build/Products/Debug-iphonesimulator/SharedPriceRepro.app'
if not app.exists():
 candidates=list((root/'derived/Build/Products/Debug-iphonesimulator').glob('*.app')); assert len(candidates)==1,candidates; app=candidates[0]
def cmd(*args,check=True):
 return subprocess.run(args,check=check,capture_output=True,text=True)
cmd('xcrun','simctl','terminate',udid,bundle,check=False)
cmd('xcrun','simctl','install',udid,str(app))
container=pathlib.Path(cmd('xcrun','simctl','get_app_container',udid,bundle,'data').stdout.strip()); resultfile=container/'Documents/results.json'
if resultfile.exists(): resultfile.unlink()
video=root/'evidence'/f'{label}.mp4'; screenshot=root/'evidence'/f'{label}.png'; logfile=root/'evidence'/f'{label}-native.log'
with open(root/'evidence'/f'{label}-capture.log','w') as capture,open(logfile,'w') as native:
 recorder=subprocess.Popen(['xcrun','simctl','io',udid,'recordVideo','--display='+display,'--codec=h264','--force',str(video)],stdout=capture,stderr=capture)
 logger=subprocess.Popen(['xcrun','simctl','spawn',udid,'log','stream','--level','debug','--style','compact','--predicate',f'process == "{app.stem}"'],stdout=native,stderr=native)
 try:
  time.sleep(1); print(cmd('xcrun','simctl','launch',udid,bundle).stdout,flush=True)
  end=time.time()+90; result={}
  while time.time()<end:
   if resultfile.exists():
    try: result=json.loads(resultfile.read_text())
    except json.JSONDecodeError: pass
    if result.get('finished') or result.get('error'): break
   time.sleep(.5)
  time.sleep(2)
  cmd('xcrun','simctl','io',udid,'screenshot','--display='+display,str(screenshot))
 finally:
  recorder.send_signal(signal.SIGINT)
  try: recorder.wait(timeout=15)
  except subprocess.TimeoutExpired: recorder.terminate(); recorder.wait()
  logger.terminate(); logger.wait(timeout=10)
if not resultfile.exists(): raise RuntimeError('App did not produce results.json')
result['binaryPath']=str(app); result['recording']=str(video); result['screenshot']=str(screenshot)
(root/'evidence'/f'{label}-results.json').write_text(json.dumps(result,indent=2))
for check in result.get('checks',[]): print(('PASS' if check['pass'] else 'FAIL')+' '+check['name']+' actual='+json.dumps(check.get('actual', '<undefined>')))
if not result.get('finished'): print('INCOMPLETE',result.get('error','timeout')); sys.exit(2)
print(f"{result['passed']} passed / {result['failed']} failed")
sys.exit(1 if result['failed'] else 0)
