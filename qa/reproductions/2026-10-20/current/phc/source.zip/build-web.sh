#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p worktrees/purchases-hybrid-common
tar -xzf sdk-source.tar.gz -C worktrees/purchases-hybrid-common
(cd worktrees/purchases-hybrid-common/purchases-js-hybrid-mappings && corepack yarn install --frozen-lockfile && npm run build)
cp worktrees/purchases-hybrid-common/purchases-js-hybrid-mappings/dist/index.umd.js web-app/before.js
(cd worktrees/purchases-hybrid-common && patch -p1 < ../../fixes/phc-web.patch)
(cd worktrees/purchases-hybrid-common/purchases-js-hybrid-mappings && npm run build)
cp worktrees/purchases-hybrid-common/purchases-js-hybrid-mappings/dist/index.umd.js web-app/fixed.js
python3 -m http.server 8887 --bind 127.0.0.1 --directory web-app
