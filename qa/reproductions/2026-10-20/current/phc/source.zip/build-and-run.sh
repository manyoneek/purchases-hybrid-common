#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
variant="${1:-before}"
export LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
mkdir -p worktrees/purchases-hybrid-common
tar -xzf sdk-source.tar.gz -C worktrees/purchases-hybrid-common
if [ "$variant" = fixed ]; then
 (cd worktrees/purchases-hybrid-common && patch -p1 < ../../fixes/phc-ios.patch && patch -p1 < ../../fixes/phc-web.patch)
fi
(cd native-app && xcodegen generate && pod install && xcodebuild build -workspace SharedPriceRepro.xcworkspace -scheme SharedPriceRepro -destination "platform=iOS Simulator,id=${QA_SIMULATOR:?Set QA_SIMULATOR}" -derivedDataPath ../derived CODE_SIGNING_ALLOWED=NO)
python3 run-native-regression.py "$variant"
